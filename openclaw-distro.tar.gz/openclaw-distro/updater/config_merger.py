"""
OpenClaw Distro — Config Merger

Three-layer config precedence (highest to lowest):
1. User overrides (configs/user/local.yaml) — never auto-modified
2. Distro overlay (configs/overlays/{use_case}/) — auto-updated with distro
3. Base defaults (configs/base/) — auto-updated with upstream

Usage:
    python updater/config_merger.py
"""

import sys
import yaml
from pathlib import Path
from deepmerge import always_merger

SCRIPT_DIR = Path(__file__).parent.parent
CONFIGS_DIR = SCRIPT_DIR / "configs"
OUTPUT_DIR = SCRIPT_DIR / "data" / "config"


def load_yaml(path: Path) -> dict:
    if path.exists():
        with open(path) as f:
            return yaml.safe_load(f) or {}
    return {}


def merge_configs():
    # Detect use case from user config
    user_config = load_yaml(CONFIGS_DIR / "user" / "local.yaml")
    use_case = user_config.get("use_case", "general-purpose")

    # Load layers
    base = load_yaml(CONFIGS_DIR / "base" / "openclaw.yaml")
    overlay = load_yaml(CONFIGS_DIR / "overlays" / use_case / "override.yaml")
    user = user_config

    # Merge: base <- overlay <- user
    merged = always_merger.merge(
        always_merger.merge(dict(base), dict(overlay)),
        dict(user)
    )

    # Write final config
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / "merged.yaml"
    with open(output_path, "w") as f:
        yaml.dump(merged, f, default_flow_style=False, sort_keys=False)

    print(f"Config merged: base + {use_case} overlay + user -> {output_path}")
    return merged


if __name__ == "__main__":
    merge_configs()
