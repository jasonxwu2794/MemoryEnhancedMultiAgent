#!/usr/bin/env bash
set -euo pipefail

# ─── OpenClaw Distro Installer ─────────────────────────────────────────────
# One-command setup for the full multi-agent OpenClaw distribution.
# Requires: Docker, git. Installs gum if not present.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
USER_CONFIG="$SCRIPT_DIR/configs/user/local.yaml"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  🦀 OpenClaw Distro — Multi-Agent Installer  ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════╝${NC}"
echo ""

# ─── Step 0: Prerequisites ─────────────────────────────────────────────────

check_prereqs() {
    local missing=()

    if ! command -v docker &>/dev/null; then missing+=("docker"); fi
    if ! command -v docker compose &>/dev/null && ! command -v docker-compose &>/dev/null; then
        missing+=("docker-compose")
    fi
    if ! command -v git &>/dev/null; then missing+=("git"); fi

    if [ ${#missing[@]} -gt 0 ]; then
        echo -e "${RED}Missing prerequisites: ${missing[*]}${NC}"
        echo "Please install them and re-run this script."
        exit 1
    fi

    echo -e "${GREEN}✓ Prerequisites OK${NC} (docker, docker-compose, git)"

    # Install gum if not present
    if ! command -v gum &>/dev/null; then
        echo -e "${YELLOW}Installing gum (terminal UI toolkit)...${NC}"
        if command -v brew &>/dev/null; then
            brew install gum
        elif [ -f /etc/debian_version ]; then
            sudo mkdir -p /etc/apt/keyrings
            curl -fsSL https://repo.charm.sh/apt/gpg.key | sudo gpg --dearmor -o /etc/apt/keyrings/charm.gpg
            echo "deb [signed-by=/etc/apt/keyrings/charm.gpg] https://repo.charm.sh/apt/ * *" | sudo tee /etc/apt/sources.list.d/charm.list
            sudo apt update && sudo apt install -y gum
        else
            echo -e "${RED}Cannot auto-install gum. Install manually: https://github.com/charmbracelet/gum${NC}"
            exit 1
        fi
    fi
    echo -e "${GREEN}✓ gum available${NC}"
}

# ─── Step 1: Use Case ──────────────────────────────────────────────────────

select_use_case() {
    echo ""
    gum style --bold --foreground 212 "Step 1: Select your primary use case"
    echo ""

    USE_CASE=$(gum choose \
        "general-purpose" \
        "coding-assistant" \
        "research-agent" \
        "trading-analyst" \
        "custom")

    echo -e "${GREEN}✓ Use case: ${USE_CASE}${NC}"
}

# ─── Step 2: Agent Mode ────────────────────────────────────────────────────

select_agent_mode() {
    echo ""
    gum style --bold --foreground 212 "Step 2: Agent configuration"
    echo ""

    AGENT_MODE=$(gum choose \
        "full (Brain + Builder + Fact Checker + Researcher + Guardian)" \
        "standard (Brain + Builder + Fact Checker)" \
        "duo (Brain + Builder)" \
        "solo (single agent, classic mode)")

    echo -e "${GREEN}✓ Agent mode: ${AGENT_MODE}${NC}"
}

# ─── Step 3: Model Selection ───────────────────────────────────────────────

select_models() {
    echo ""
    gum style --bold --foreground 212 "Step 3: Model selection per agent"
    echo ""

    echo "Brain (orchestration, synthesis):"
    BRAIN_MODEL=$(gum choose \
        "moonshot/kimi-k2.5" \
        "anthropic/claude-sonnet-4-20250514" \
        "qwen/qwen-max" \
        "google/gemini-2.5-pro" \
        "custom...")

    if [ "$BRAIN_MODEL" = "custom..." ]; then
        BRAIN_MODEL=$(gum input --placeholder "model-provider/model-name")
    fi

    echo ""
    echo "Builder (code generation):"
    BUILDER_MODEL=$(gum choose \
        "deepseek/deepseek-chat" \
        "moonshot/kimi-k2.5" \
        "mistralai/codestral-latest" \
        "anthropic/claude-sonnet-4-20250514" \
        "custom...")

    if [ "$BUILDER_MODEL" = "custom..." ]; then
        BUILDER_MODEL=$(gum input --placeholder "model-provider/model-name")
    fi

    echo ""
    echo "Fact Checker + Researcher (precision + reasoning):"
    CHECKER_MODEL=$(gum choose \
        "qwen/qwen-max" \
        "anthropic/claude-sonnet-4-20250514" \
        "moonshot/kimi-k2.5" \
        "google/gemini-2.5-pro" \
        "custom...")

    if [ "$CHECKER_MODEL" = "custom..." ]; then
        CHECKER_MODEL=$(gum input --placeholder "model-provider/model-name")
    fi

    RESEARCHER_MODEL="$CHECKER_MODEL"
    GUARDIAN_MODEL="$CHECKER_MODEL"

    echo -e "${GREEN}✓ Models configured${NC}"
}

# ─── Step 4: API Keys ──────────────────────────────────────────────────────

configure_api_keys() {
    echo ""
    gum style --bold --foreground 212 "Step 4: API keys"
    echo ""

    echo "OpenRouter API key (required for LLM access):"
    OPENROUTER_API_KEY=$(gum input --placeholder "sk-or-..." --password)

    echo ""
    gum style --bold --foreground 212 "Web search backend (optional, for Researcher + Fact Checker):"
    SEARCH_BACKEND=$(gum choose \
        "brave (recommended — 2000 free req/month)" \
        "tavily (built for AI agents)" \
        "serpapi (Google results)" \
        "none (LLM knowledge only)")
    SEARCH_BACKEND="${SEARCH_BACKEND%% *}"

    BRAVE_API_KEY=""
    TAVILY_API_KEY=""
    SERPAPI_API_KEY=""

    if [ "$SEARCH_BACKEND" = "brave" ]; then
        echo "Brave Search API key (https://brave.com/search/api/):"
        BRAVE_API_KEY=$(gum input --placeholder "BSA..." --password)
    elif [ "$SEARCH_BACKEND" = "tavily" ]; then
        echo "Tavily API key (https://tavily.com/):"
        TAVILY_API_KEY=$(gum input --placeholder "tvly-..." --password)
    elif [ "$SEARCH_BACKEND" = "serpapi" ]; then
        echo "SerpAPI key (https://serpapi.com/):"
        SERPAPI_API_KEY=$(gum input --placeholder "..." --password)
    fi

    echo ""
    echo "GitHub token (optional, for GitHub MCP tools):"
    GITHUB_TOKEN=$(gum input --placeholder "ghp_... (press Enter to skip)" --password)

    echo ""
    echo "Telegram bot token (optional, for Telegram integration):"
    TELEGRAM_TOKEN=$(gum input --placeholder "123456:ABC... (press Enter to skip)" --password)

    echo -e "${GREEN}✓ API keys configured${NC}"
}

# ─── Step 5: Memory Configuration ──────────────────────────────────────────

configure_memory() {
    echo ""
    gum style --bold --foreground 212 "Step 5: Memory system"
    echo ""

    MEMORY_TIER=$(gum choose \
        "full (LanceDB vectors + SQLite + Knowledge Cache)" \
        "standard (LanceDB + SQLite)" \
        "minimal (SQLite only)")

    echo -e "${GREEN}✓ Memory: ${MEMORY_TIER}${NC}"
}

# ─── Step 6: Tools ─────────────────────────────────────────────────────────

select_tools() {
    echo ""
    gum style --bold --foreground 212 "Step 6: Select tools to install"
    echo ""

    TOOLS=$(gum choose --no-limit \
        "filesystem (local file access)" \
        "github (repo management)" \
        "web-search (Tavily/SerpAPI)" \
        "browser (Playwright automation)" \
        "code-sandbox (isolated execution)" \
        "database (SQLite/Postgres query tool)")

    echo -e "${GREEN}✓ Tools selected${NC}"
}

# ─── Step 7: Generate & Deploy ─────────────────────────────────────────────

generate_and_deploy() {
    echo ""
    gum style --bold --foreground 212 "Step 7: Generating configuration..."
    echo ""

    # Write .env file
    cat > "$ENV_FILE" <<EOF
# OpenClaw Distro — Generated $(date -u +%Y-%m-%dT%H:%M:%SZ)
# DO NOT commit this file to git

# LLM Configuration
OPENROUTER_API_KEY=${OPENROUTER_API_KEY}
LLM_BASE_URL=https://openrouter.ai/api/v1

# Agent Models
BRAIN_MODEL=${BRAIN_MODEL}
BUILDER_MODEL=${BUILDER_MODEL}
CHECKER_MODEL=${CHECKER_MODEL}
RESEARCHER_MODEL=${RESEARCHER_MODEL}
GUARDIAN_MODEL=${GUARDIAN_MODEL}

# Integrations
GITHUB_TOKEN=${GITHUB_TOKEN:-}
TELEGRAM_TOKEN=${TELEGRAM_TOKEN:-}

# Web Search
SEARCH_BACKEND=${SEARCH_BACKEND:-none}
BRAVE_API_KEY=${BRAVE_API_KEY:-}
TAVILY_API_KEY=${TAVILY_API_KEY:-}
SERPAPI_API_KEY=${SERPAPI_API_KEY:-}

# Resource Limits
COST_BUDGET_DAILY_TOKENS=1000000
LOG_LEVEL=INFO
EOF

    echo -e "${GREEN}✓ .env generated${NC}"

    # Write user config
    mkdir -p "$(dirname "$USER_CONFIG")"
    cat > "$USER_CONFIG" <<EOF
# OpenClaw Distro — User Configuration
# This file is gitignored and never auto-modified.
# Your overrides here take highest precedence.

use_case: ${USE_CASE}
agent_mode: ${AGENT_MODE%% *}

# Add your custom overrides below:
# memory:
#   recency_half_life_days: 14
# agents:
#   brain:
#     temperature: 0.8
EOF

    echo -e "${GREEN}✓ User config generated${NC}"

    # Add .env to gitignore
    if ! grep -q "^\.env$" "$SCRIPT_DIR/.gitignore" 2>/dev/null; then
        echo -e ".env\nconfigs/user/\ndata/" >> "$SCRIPT_DIR/.gitignore"
    fi

    # Initialize git if not already
    if [ ! -d "$SCRIPT_DIR/.git" ]; then
        git -C "$SCRIPT_DIR" init
        git -C "$SCRIPT_DIR" add -A
        git -C "$SCRIPT_DIR" commit -m "Initial OpenClaw Distro setup"
        echo -e "${GREEN}✓ Git repo initialized${NC}"
    fi

    # Build and start
    echo ""
    gum style --bold --foreground 212 "Building and starting services..."
    echo ""

    docker compose -f "$SCRIPT_DIR/docker-compose.yml" build
    docker compose -f "$SCRIPT_DIR/docker-compose.yml" up -d

    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  ✅ OpenClaw Distro is running!               ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
    echo ""
    echo "  Useful commands:"
    echo "    docker compose logs -f          # View all logs"
    echo "    docker compose logs brain -f    # View Brain logs"
    echo "    make deploy                     # Redeploy after config change"
    echo "    make update                     # Pull latest updates"
    echo "    make rollback                   # Revert last deploy"
    echo ""
}

# ─── Main ───────────────────────────────────────────────────────────────────

main() {
    check_prereqs
    select_use_case
    select_agent_mode
    select_models
    configure_api_keys
    configure_memory
    select_tools
    generate_and_deploy
}

main "$@"
