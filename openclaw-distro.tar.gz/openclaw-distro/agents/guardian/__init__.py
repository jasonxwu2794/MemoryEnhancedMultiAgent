"""
OpenClaw Distro — Guardian Agent Package

Entry point: python -m agents.guardian
"""

import asyncio
from agents.common.base_agent import run_agent
from .guardian import GuardianAgent


def main():
    asyncio.run(run_agent(GuardianAgent))


if __name__ == "__main__":
    main()