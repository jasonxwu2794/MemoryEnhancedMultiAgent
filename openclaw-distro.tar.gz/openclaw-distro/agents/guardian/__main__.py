"""Entry point for: python -m agents.guardian"""
from agents.guardian import main

main()
