"""
OpenClaw Distro — Researcher Agent Package

Entry point: python -m agents.researcher
"""

import asyncio
from agents.common.base_agent import run_agent
from .researcher import ResearcherAgent


def main():
    asyncio.run(run_agent(ResearcherAgent))


if __name__ == "__main__":
    main()