"""Entry point for: python -m agents.researcher"""
from agents.researcher import main

main()
