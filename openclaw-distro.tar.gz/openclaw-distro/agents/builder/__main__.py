"""Entry point for: python -m agents.builder"""
from agents.builder import main

main()
