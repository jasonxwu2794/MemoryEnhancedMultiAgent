"""
OpenClaw Distro — Builder Agent Package

Entry point: python -m agents.builder
"""

import asyncio
from agents.common.base_agent import run_agent
from .builder import BuilderAgent


def main():
    asyncio.run(run_agent(BuilderAgent))


if __name__ == "__main__":
    main()