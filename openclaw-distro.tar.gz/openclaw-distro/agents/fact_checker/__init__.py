"""
OpenClaw Distro — Fact Checker Agent Package

Entry point: python -m agents.fact_checker
"""

import asyncio
from agents.common.base_agent import run_agent
from .fact_checker import FactCheckerAgent


def main():
    asyncio.run(run_agent(FactCheckerAgent))


if __name__ == "__main__":
    main()