"""Entry point for: python -m agents.fact_checker"""
from agents.fact_checker import main

main()
