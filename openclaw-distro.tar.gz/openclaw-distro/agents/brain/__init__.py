"""
OpenClaw Distro — Brain Agent Package

Entry point: python -m agents.brain
"""

import asyncio
from agents.common.base_agent import run_agent
from .brain import BrainAgent


def main():
    asyncio.run(run_agent(BrainAgent))


if __name__ == "__main__":
    main()