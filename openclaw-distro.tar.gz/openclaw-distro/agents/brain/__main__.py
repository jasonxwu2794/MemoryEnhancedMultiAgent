"""Entry point for: python -m agents.brain"""
from agents.brain import main

main()
