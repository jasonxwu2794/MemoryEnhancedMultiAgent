"""
OpenClaw Distro — Sub-Agent Pool

Lightweight parallel workers within a parent agent's container.
NOT separate containers — concurrent LLM calls with isolated context.

Used by:
- Researcher: ALWAYS (3-6 parallel investigation threads)
- Builder: When multi-component builds require parallel generation
- Fact Checker: When batch-verifying 3+ claims in parallel
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class SubTask:
    """A unit of work for a sub-agent."""
    id: str
    description: str
    context: dict = field(default_factory=dict)
    constraints: dict = field(default_factory=dict)
    system_prompt_override: Optional[str] = None


@dataclass
class SubResult:
    """Result from a sub-agent execution."""
    task_id: str
    output: dict
    confidence: float = 0.5
    duration_ms: int = 0
    error: Optional[str] = None
    tokens_used: int = 0

    @property
    def success(self) -> bool:
        return self.error is None


class SubAgentPool:
    """
    Manages concurrent sub-agent executions within a parent agent.

    Features:
    - Semaphore-based concurrency control
    - Per-task timeout
    - Token/cost budget tracking
    - Graceful degradation (returns partial results on timeout)
    """

    def __init__(self, llm_client, system_prompt: str,
                 max_concurrent: int = 5, task_timeout: float = 60.0):
        self.llm = llm_client
        self.system_prompt = system_prompt
        self.max_concurrent = max_concurrent
        self.task_timeout = task_timeout
        self.semaphore = asyncio.Semaphore(max_concurrent)

        # Metrics
        self.total_calls = 0
        self.total_tokens = 0
        self.total_duration_ms = 0

    async def execute_parallel(
        self,
        subtasks: list[SubTask],
        budget: Optional[dict] = None
    ) -> list[SubResult]:
        """
        Execute multiple subtasks concurrently.

        Args:
            subtasks: List of SubTask objects
            budget: Optional {"max_calls": int, "max_tokens": int}

        Returns:
            List of SubResult objects (same order as input)
        """
        budget = budget or {"max_calls": 10, "max_tokens": 100_000}

        # Enforce budget: trim if too many tasks
        if len(subtasks) > budget["max_calls"]:
            logger.warning(
                f"Trimming {len(subtasks)} subtasks to budget of {budget['max_calls']}"
            )
            subtasks = subtasks[:budget["max_calls"]]

        logger.info(f"Executing {len(subtasks)} sub-tasks in parallel "
                     f"(max_concurrent={self.max_concurrent})")

        # Run all subtasks concurrently with individual error handling
        results = await asyncio.gather(
            *[self._run_subtask(task) for task in subtasks],
            return_exceptions=False
        )

        # Log metrics
        successful = sum(1 for r in results if r.success)
        total_tokens = sum(r.tokens_used for r in results)
        total_ms = sum(r.duration_ms for r in results)

        logger.info(
            f"Sub-agent pool: {successful}/{len(results)} succeeded, "
            f"{total_tokens} tokens, {total_ms}ms total"
        )

        self.total_calls += len(results)
        self.total_tokens += total_tokens
        self.total_duration_ms += total_ms

        return results

    async def _run_subtask(self, task: SubTask) -> SubResult:
        """Execute a single subtask with semaphore and timeout."""
        async with self.semaphore:
            start = time.monotonic()
            try:
                async with asyncio.timeout(self.task_timeout):
                    response = await self.llm.generate(
                        system=task.system_prompt_override or self.system_prompt,
                        messages=[{
                            "role": "user",
                            "content": self._format_subtask_prompt(task)
                        }]
                    )

                    elapsed_ms = int((time.monotonic() - start) * 1000)

                    return SubResult(
                        task_id=task.id,
                        output=response.get("content", {}),
                        confidence=response.get("confidence", 0.5),
                        duration_ms=elapsed_ms,
                        tokens_used=response.get("usage", {}).get("total_tokens", 0)
                    )

            except asyncio.TimeoutError:
                elapsed_ms = int((time.monotonic() - start) * 1000)
                logger.warning(f"Sub-task {task.id} timed out after {elapsed_ms}ms")
                return SubResult(
                    task_id=task.id,
                    output={},
                    confidence=0.0,
                    duration_ms=elapsed_ms,
                    error=f"Timeout after {self.task_timeout}s"
                )

            except Exception as e:
                elapsed_ms = int((time.monotonic() - start) * 1000)
                logger.error(f"Sub-task {task.id} failed: {e}")
                return SubResult(
                    task_id=task.id,
                    output={},
                    confidence=0.0,
                    duration_ms=elapsed_ms,
                    error=str(e)
                )

    def _format_subtask_prompt(self, task: SubTask) -> str:
        """Format the subtask into a clear prompt for the LLM."""
        parts = [f"## Task\n{task.description}"]

        if task.context:
            parts.append(f"\n## Context\n```json\n"
                         f"{__import__('json').dumps(task.context, indent=2)}\n```")

        if task.constraints:
            constraints_str = "\n".join(
                f"- {k}: {v}" for k, v in task.constraints.items()
            )
            parts.append(f"\n## Constraints\n{constraints_str}")

        parts.append(
            "\n## Instructions\n"
            "Respond with a JSON object containing:\n"
            "- `content`: Your main output\n"
            "- `confidence`: Float 0.0-1.0 for how confident you are\n"
            "- `claims`: List of any factual claims made (for verification)\n"
            "- `notes`: Any caveats or uncertainties"
        )

        return "\n".join(parts)

    def get_metrics(self) -> dict:
        """Return cumulative metrics for cost tracking."""
        return {
            "total_calls": self.total_calls,
            "total_tokens": self.total_tokens,
            "total_duration_ms": self.total_duration_ms,
            "avg_duration_ms": (
                self.total_duration_ms // self.total_calls
                if self.total_calls > 0 else 0
            ),
        }
