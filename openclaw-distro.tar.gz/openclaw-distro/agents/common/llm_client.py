"""
OpenClaw Distro — Unified LLM Client

Wraps OpenRouter (or any OpenAI-compatible API) with:
- Retry logic with exponential backoff
- Token counting and cost tracking
- JSON mode support
- Streaming support
- Fallback model chain
"""

import json
import logging
import asyncio
from typing import Optional, AsyncIterator

import httpx

logger = logging.getLogger(__name__)


class LLMClient:
    """
    Unified LLM client for all agents.

    Supports OpenRouter, OpenAI, Anthropic, and any OpenAI-compatible endpoint.
    """

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        base_url: str = "https://openrouter.ai/api/v1",
        fallback_models: list[str] = None,
        max_retries: int = 3,
        timeout: float = 120.0,
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.fallback_models = fallback_models or []
        self.max_retries = max_retries
        self.timeout = timeout

        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/openclaw-distro",
            },
        )

        # Metrics
        self.total_requests = 0
        self.total_tokens = 0
        self.total_cost = 0.0

    async def generate(
        self,
        system: str = None,
        messages: list[dict] = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        json_mode: bool = False,
    ) -> dict:
        """
        Generate a completion.

        Returns:
            {
                "content": str or dict (if json_mode),
                "usage": {"prompt_tokens": int, "completion_tokens": int, "total_tokens": int},
                "model": str,
                "confidence": float (if json_mode and model returns it)
            }
        """
        # Build messages array
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        if messages:
            msgs.extend(messages)

        # Try primary model, then fallbacks
        models_to_try = [self.model] + self.fallback_models

        for model in models_to_try:
            try:
                return await self._call_api(
                    model=model,
                    messages=msgs,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    json_mode=json_mode,
                )
            except Exception as e:
                logger.warning(f"Model {model} failed: {e}")
                if model == models_to_try[-1]:
                    raise  # Last model, propagate error
                continue

    async def generate_json(
        self,
        prompt: str,
        system: str = None,
        temperature: float = 0.3,
    ) -> dict:
        """
        Generate a JSON response. Automatically handles parsing and retries.
        """
        if system is None:
            system = (
                "You are a precise assistant. Respond ONLY with valid JSON. "
                "No markdown, no backticks, no preamble."
            )

        result = await self.generate(
            system=system,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            json_mode=True,
        )

        content = result["content"]

        # Parse if string
        if isinstance(content, str):
            # Strip markdown fences if present
            content = content.strip()
            if content.startswith("```"):
                content = content.split("\n", 1)[1]
                if content.endswith("```"):
                    content = content[:-3]
                content = content.strip()

            content = json.loads(content)

        result["content"] = content
        return result

    async def _call_api(
        self,
        model: str,
        messages: list,
        temperature: float,
        max_tokens: int,
        json_mode: bool,
    ) -> dict:
        """Make the actual API call with retries."""
        body = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if json_mode:
            body["response_format"] = {"type": "json_object"}

        for attempt in range(self.max_retries):
            try:
                response = await self._client.post(
                    f"{self.base_url}/chat/completions",
                    json=body,
                )
                response.raise_for_status()
                data = response.json()

                # Extract result
                choice = data["choices"][0]
                usage = data.get("usage", {})

                self.total_requests += 1
                self.total_tokens += usage.get("total_tokens", 0)

                content = choice["message"]["content"]

                return {
                    "content": content,
                    "usage": usage,
                    "model": data.get("model", model),
                }

            except httpx.HTTPStatusError as e:
                if e.response.status_code == 429:
                    # Rate limited — backoff
                    wait = 2 ** attempt
                    logger.warning(f"Rate limited, waiting {wait}s (attempt {attempt + 1})")
                    await asyncio.sleep(wait)
                elif e.response.status_code >= 500:
                    wait = 2 ** attempt
                    logger.warning(f"Server error {e.response.status_code}, "
                                   f"retrying in {wait}s")
                    await asyncio.sleep(wait)
                else:
                    raise

            except httpx.TimeoutException:
                if attempt < self.max_retries - 1:
                    logger.warning(f"Timeout, retrying (attempt {attempt + 1})")
                    await asyncio.sleep(1)
                else:
                    raise

        raise RuntimeError(f"Failed after {self.max_retries} retries")

    def get_metrics(self) -> dict:
        return {
            "total_requests": self.total_requests,
            "total_tokens": self.total_tokens,
            "model": self.model,
        }

    async def close(self):
        await self._client.aclose()
