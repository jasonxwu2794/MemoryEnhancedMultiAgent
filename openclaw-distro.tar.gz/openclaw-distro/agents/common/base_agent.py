"""
OpenClaw Distro — Base Agent

Shared scaffolding for all agents. Handles:
- Message bus connection and listening
- LLM client initialization
- Memory access (scoped per agent permissions)
- Graceful startup/shutdown
- Health checks
"""

import asyncio
import logging
import os
from abc import ABC, abstractmethod
from typing import Optional

from .protocol import AgentRole, AgentMessage, MessageBus, TaskStatus
from .sub_agent import SubAgentPool

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Abstract base class for all agents.

    Subclasses must implement:
    - handle_task(msg: AgentMessage) → Process an incoming task
    - system_prompt → Property returning the agent's system prompt

    Optional overrides:
    - on_startup() → Called after connection
    - on_shutdown() → Called before disconnect
    """

    def __init__(self):
        self.role = AgentRole(os.environ.get("ROLE", "brain"))
        self.bus = MessageBus(os.environ.get("REDIS_URL", "redis://message-bus:6379"))
        self.llm = None  # Initialized in startup
        self.memory = None  # Initialized in startup if permitted
        self.web_search = None  # Initialized in startup if permitted
        self.sub_pool: Optional[SubAgentPool] = None

        # Permissions from environment
        self.can_delegate = os.environ.get("CAN_DELEGATE", "false").lower() == "true"
        self.can_write_memory = os.environ.get("CAN_WRITE_MEMORY", "false").lower() == "true"
        self.can_execute_code = os.environ.get("CAN_EXECUTE_CODE", "false").lower() == "true"
        self.can_search_web = os.environ.get("CAN_SEARCH_WEB", "false").lower() == "true"

        # Model config
        self.model_name = os.environ.get("MODEL", "moonshot/kimi-k2.5")

    async def startup(self):
        """Initialize connections and resources."""
        logger.info(f"Starting {self.role.value} agent with model {self.model_name}")

        # Connect to message bus
        await self.bus.connect()

        # Initialize LLM client
        from .llm_client import LLMClient
        self.llm = LLMClient(
            model=self.model_name,
            api_key=os.environ.get("LLM_API_KEY"),
            base_url=os.environ.get("LLM_BASE_URL", "https://openrouter.ai/api/v1"),
        )

        # Initialize memory (if permitted)
        if os.environ.get("MEMORY_ENABLED", "true").lower() == "true":
            from memory.engine import MemoryEngine
            memory_path = os.environ.get("MEMORY_PATH", "/data/memory")
            self.memory = MemoryEngine(
                db_path=memory_path,
                read_only=not self.can_write_memory
            )

        # Initialize web search (if permitted)
        if self.can_search_web:
            from .web_search import WebSearchClient
            self.web_search = WebSearchClient.from_env()
            logger.info(
                f"Web search enabled: {self.web_search.backend_name} "
                f"(available={self.web_search.is_available})"
            )

        # Initialize sub-agent pool (if this agent supports it)
        if self._supports_sub_agents():
            self.sub_pool = SubAgentPool(
                llm_client=self.llm,
                system_prompt=self.sub_agent_system_prompt,
                max_concurrent=int(os.environ.get("MAX_SUB_AGENTS", "5")),
                task_timeout=float(os.environ.get("SUB_AGENT_TIMEOUT", "60")),
            )

        # Agent-specific startup
        await self.on_startup()

        logger.info(f"{self.role.value} agent ready")

    async def run(self):
        """Main run loop — listen for messages and process them."""
        await self.startup()

        try:
            await self.bus.listen(self.role, self._handle_message)
        except asyncio.CancelledError:
            logger.info(f"{self.role.value} agent shutting down")
        finally:
            await self.shutdown()

    async def shutdown(self):
        """Clean up resources."""
        await self.on_shutdown()
        if self.web_search:
            await self.web_search.close()
        await self.bus.disconnect()
        logger.info(f"{self.role.value} agent stopped")

    async def _handle_message(self, msg: AgentMessage):
        """
        Internal message handler with error wrapping and reply.
        """
        logger.info(
            f"{self.role.value} received {msg.action} "
            f"[task:{msg.task_id[:8]}] from {msg.from_agent}"
        )

        try:
            msg.status = TaskStatus.IN_PROGRESS.value
            result = await self.handle_task(msg)

            if result is not None:
                msg.complete(result)
            # If handle_task already set status, don't override

        except Exception as e:
            logger.error(f"Error in {self.role.value}: {e}", exc_info=True)
            msg.fail(str(e))

        # Send reply back to caller
        await self.bus.reply(msg, msg)

    # ─── Abstract methods ─────────────────────────────────────────────

    @abstractmethod
    async def handle_task(self, msg: AgentMessage) -> Optional[dict]:
        """
        Process an incoming task message.

        Returns:
            dict with results, or None if the agent set msg status directly.
        """
        ...

    @property
    @abstractmethod
    def system_prompt(self) -> str:
        """The agent's primary system prompt."""
        ...

    # ─── Optional overrides ───────────────────────────────────────────

    async def on_startup(self):
        """Called after base initialization. Override for agent-specific setup."""
        pass

    async def on_shutdown(self):
        """Called before disconnect. Override for agent-specific cleanup."""
        pass

    def _supports_sub_agents(self) -> bool:
        """Override to enable sub-agent pool. Default: False."""
        return False

    @property
    def sub_agent_system_prompt(self) -> str:
        """System prompt for sub-agents. Override if using sub-agents."""
        return "You are a focused sub-agent. Complete your assigned task precisely."

    # ─── Utility methods ──────────────────────────────────────────────

    async def delegate(self, to_agent: AgentRole, action: str,
                       payload: dict, context: dict,
                       constraints: dict = None,
                       timeout: float = 120.0) -> AgentMessage:
        """
        Delegate a task to another agent and wait for response.
        Only agents with can_delegate=True can use this.
        """
        if not self.can_delegate:
            raise PermissionError(
                f"{self.role.value} does not have delegation permission"
            )

        msg = AgentMessage(
            from_agent=self.role.value,
            to_agent=to_agent.value,
            action=action,
            payload=payload,
            context=context,
            constraints=constraints or {},
        )

        return await self.bus.send_and_wait(msg, timeout=timeout)

    async def delegate_parallel(
        self,
        tasks: list[dict],
        timeout: float = 120.0
    ) -> list[AgentMessage]:
        """
        Delegate multiple tasks in parallel and wait for all responses.
        Each task dict: {"to": AgentRole, "action": str, "payload": dict, "context": dict}
        """
        if not self.can_delegate:
            raise PermissionError(
                f"{self.role.value} does not have delegation permission"
            )

        messages = [
            AgentMessage(
                from_agent=self.role.value,
                to_agent=t["to"].value,
                action=t["action"],
                payload=t["payload"],
                context=t.get("context", {}),
                constraints=t.get("constraints", {}),
            )
            for t in tasks
        ]

        results = await asyncio.gather(
            *[self.bus.send_and_wait(m, timeout=timeout) for m in messages]
        )
        return list(results)


# ─── Agent Entry Point ────────────────────────────────────────────────────────

async def run_agent(agent_class: type):
    """
    Standard entry point for running an agent.
    Usage in each agent's __main__.py:

        from agents.common.base_agent import run_agent
        from .my_agent import MyAgent
        asyncio.run(run_agent(MyAgent))
    """
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    )

    agent = agent_class()
    await agent.run()
