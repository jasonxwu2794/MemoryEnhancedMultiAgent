"""
OpenClaw Distro — Agent Communication Protocol

All agents communicate through a Redis message bus using structured messages.
No direct agent-to-agent communication. The Brain orchestrates all delegation.
The Guardian intercepts all messages for security review.
"""

import json
import uuid
import asyncio
import logging
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional, Callable, Any
from datetime import datetime

import redis.asyncio as aioredis

logger = logging.getLogger(__name__)


# ─── Enums ────────────────────────────────────────────────────────────────────

class AgentRole(Enum):
    BRAIN = "brain"
    BUILDER = "builder"
    FACT_CHECKER = "fact_checker"
    RESEARCHER = "researcher"
    GUARDIAN = "guardian"


class TaskStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_REVIEW = "needs_review"
    BLOCKED = "blocked"          # Guardian blocked this


class TaskPriority(Enum):
    LOW = 0
    NORMAL = 1
    HIGH = 2
    CRITICAL = 3


# ─── Message Format ──────────────────────────────────────────────────────────

@dataclass
class AgentMessage:
    """
    The universal message format for all agent communication.
    Every message flows through the Redis bus and is logged for audit.
    """
    task_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parent_task_id: Optional[str] = None      # For sub-tasks
    from_agent: str = "brain"                  # AgentRole.value
    to_agent: str = "builder"                  # AgentRole.value
    action: str = ""                           # "build", "verify", "research", "review"
    payload: dict = field(default_factory=dict)
    context: dict = field(default_factory=dict)  # SCOPED — only what target agent needs
    constraints: dict = field(default_factory=dict)  # Budget, time, scope limits
    priority: int = 1                          # TaskPriority.value
    status: str = "pending"                    # TaskStatus.value
    result: Optional[dict] = None
    error: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    completed_at: Optional[str] = None
    metadata: dict = field(default_factory=dict)  # Extensible metadata

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=str)

    @classmethod
    def from_json(cls, data: str) -> "AgentMessage":
        parsed = json.loads(data)
        return cls(**parsed)

    def complete(self, result: dict) -> "AgentMessage":
        """Mark message as completed with result."""
        self.status = TaskStatus.COMPLETED.value
        self.result = result
        self.completed_at = datetime.utcnow().isoformat()
        return self

    def fail(self, error: str) -> "AgentMessage":
        """Mark message as failed with error."""
        self.status = TaskStatus.FAILED.value
        self.error = error
        self.completed_at = datetime.utcnow().isoformat()
        return self

    def block(self, reason: str) -> "AgentMessage":
        """Guardian blocks this message."""
        self.status = TaskStatus.BLOCKED.value
        self.error = reason
        self.metadata["blocked_by"] = AgentRole.GUARDIAN.value
        self.completed_at = datetime.utcnow().isoformat()
        return self


# ─── Message Bus ──────────────────────────────────────────────────────────────

class MessageBus:
    """
    Redis-based message bus for agent communication.

    Features:
    - Pub/sub channels per agent role
    - Audit trail for all messages (stored in Redis lists)
    - Request/reply pattern with async waiting
    - Guardian interception channel
    """

    def __init__(self, redis_url: str = "redis://message-bus:6379"):
        self.redis_url = redis_url
        self._redis: Optional[aioredis.Redis] = None
        self._pubsub: Optional[aioredis.client.PubSub] = None

    async def connect(self):
        """Initialize Redis connection."""
        self._redis = aioredis.from_url(self.redis_url, decode_responses=True)
        self._pubsub = self._redis.pubsub()
        logger.info(f"Connected to message bus at {self.redis_url}")

    async def disconnect(self):
        """Clean up connections."""
        if self._pubsub:
            await self._pubsub.unsubscribe()
            await self._pubsub.close()
        if self._redis:
            await self._redis.close()

    async def send(self, msg: AgentMessage):
        """
        Send a message to an agent's channel.
        Also publishes to guardian intercept channel for security review.
        Also stores in audit trail.
        """
        channel = f"agent:{msg.to_agent}"
        payload = msg.to_json()

        # Publish to target agent
        await self._redis.publish(channel, payload)

        # Publish to guardian intercept (guardian sees ALL messages)
        await self._redis.publish("guardian:intercept", payload)

        # Audit trail
        await self._redis.lpush(f"audit:{msg.task_id}", payload)
        await self._redis.expire(f"audit:{msg.task_id}", 86400 * 7)  # 7 day retention

        logger.debug(f"Sent {msg.action} from {msg.from_agent} to {msg.to_agent} "
                      f"[task:{msg.task_id[:8]}]")

    async def send_and_wait(self, msg: AgentMessage, timeout: float = 120.0) -> AgentMessage:
        """
        Send a message and wait for the response.
        Uses a reply channel unique to the task_id.
        """
        reply_channel = f"reply:{msg.task_id}"

        # Subscribe to reply channel before sending
        reply_pubsub = self._redis.pubsub()
        await reply_pubsub.subscribe(reply_channel)

        # Send the message
        await self.send(msg)

        # Wait for reply
        try:
            async with asyncio.timeout(timeout):
                async for message in reply_pubsub.listen():
                    if message["type"] == "message":
                        reply = AgentMessage.from_json(message["data"])
                        await reply_pubsub.unsubscribe(reply_channel)
                        await reply_pubsub.close()
                        return reply
        except asyncio.TimeoutError:
            logger.warning(f"Timeout waiting for reply to task {msg.task_id[:8]}")
            await reply_pubsub.unsubscribe(reply_channel)
            await reply_pubsub.close()
            return msg.fail(f"Timeout after {timeout}s waiting for {msg.to_agent}")

    async def reply(self, original_msg: AgentMessage, response: AgentMessage):
        """Send a reply to a send_and_wait call."""
        reply_channel = f"reply:{original_msg.task_id}"
        await self._redis.publish(reply_channel, response.to_json())

        # Also audit the reply
        await self._redis.lpush(f"audit:{original_msg.task_id}", response.to_json())

    async def listen(self, role: AgentRole, callback: Callable):
        """
        Listen for messages on an agent's channel.
        The callback receives an AgentMessage and should return a response.
        """
        channel = f"agent:{role.value}"
        await self._pubsub.subscribe(channel)

        logger.info(f"Agent {role.value} listening on channel {channel}")

        async for message in self._pubsub.listen():
            if message["type"] == "message":
                try:
                    msg = AgentMessage.from_json(message["data"])
                    await callback(msg)
                except Exception as e:
                    logger.error(f"Error processing message in {role.value}: {e}")

    async def listen_intercept(self, callback: Callable):
        """Guardian-specific: listen to ALL agent messages."""
        intercept_pubsub = self._redis.pubsub()
        await intercept_pubsub.subscribe("guardian:intercept")

        async for message in intercept_pubsub.listen():
            if message["type"] == "message":
                try:
                    msg = AgentMessage.from_json(message["data"])
                    await callback(msg)
                except Exception as e:
                    logger.error(f"Guardian intercept error: {e}")

    async def get_audit_trail(self, task_id: str) -> list[AgentMessage]:
        """Retrieve the full audit trail for a task."""
        raw = await self._redis.lrange(f"audit:{task_id}", 0, -1)
        return [AgentMessage.from_json(r) for r in raw]


# ─── Context Scoping Helpers ─────────────────────────────────────────────────

class ContextScope:
    """
    Utility for the Brain to scope context before delegating.
    Each agent should only see what it needs.
    """

    @staticmethod
    def for_builder(conversation: list, workspace_state: dict,
                    tools: list) -> dict:
        """Technical context only."""
        return {
            "recent_code": ContextScope._extract_code_blocks(conversation),
            "workspace": workspace_state,
            "available_tools": tools,
            "recent_errors": ContextScope._extract_errors(conversation[-5:]),
        }

    @staticmethod
    def for_fact_checker(claims: list, knowledge_excerpts: list) -> dict:
        """Claims and reference material only."""
        return {
            "claims_to_verify": claims,
            "known_facts": knowledge_excerpts,
        }

    @staticmethod
    def for_researcher(query: str, knowledge_gaps: list,
                       preferred_sources: list = None) -> dict:
        """Research query and constraints only."""
        return {
            "query": query,
            "knowledge_gaps": knowledge_gaps,
            "preferred_sources": preferred_sources or [],
            "avoid_sources": [],  # populated from config
        }

    @staticmethod
    def for_guardian(output: dict, permissions: dict,
                     cost_budget: dict) -> dict:
        """Full output under review + policy context."""
        return {
            "content_to_review": output,
            "permissions": permissions,
            "cost_budget": cost_budget,
        }

    @staticmethod
    def _extract_code_blocks(conversation: list) -> list:
        """Pull code blocks from recent conversation."""
        import re
        code_blocks = []
        for msg in conversation[-10:]:
            content = msg.get("content", "")
            blocks = re.findall(r"```[\w]*\n(.*?)```", content, re.DOTALL)
            code_blocks.extend(blocks)
        return code_blocks[-5:]  # Last 5 code blocks

    @staticmethod
    def _extract_errors(messages: list) -> list:
        """Pull error messages from recent conversation."""
        errors = []
        error_keywords = ["error", "traceback", "exception", "failed", "TypeError",
                          "ValueError", "SyntaxError", "ImportError"]
        for msg in messages:
            content = msg.get("content", "").lower()
            if any(kw.lower() in content for kw in error_keywords):
                errors.append(msg.get("content", "")[:500])
        return errors
