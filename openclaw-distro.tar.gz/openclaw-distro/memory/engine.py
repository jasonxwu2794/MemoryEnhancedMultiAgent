"""
OpenClaw Distro — Memory Engine

Three-tier memory with importance scoring and recency decay.

Tiers:
1. Working Memory  — Current conversation context (in-context window, not managed here)
2. Short-term      — Recent interactions, high recency score (LanceDB vectors)
3. Long-term       — Consolidated knowledge, high importance score (LanceDB + SQLite)

Knowledge Cache    — Verified facts with no decay (SQLite)

Scoring:
- Semantic similarity: Cosine distance from query embedding (LanceDB)
- Recency score: Exponential decay with configurable half-life
- Importance score: Heuristic based on user signals, repetition, corrections
"""

import json
import math
import sqlite3
import logging
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# LanceDB is optional — graceful fallback if not installed
try:
    import lancedb
    import pyarrow as pa
    LANCEDB_AVAILABLE = True
except ImportError:
    LANCEDB_AVAILABLE = False
    logger.warning("LanceDB not available — running in SQLite-only mode")


# ─── Configuration ────────────────────────────────────────────────────────────

DEFAULT_CONFIG = {
    "recency_half_life_days": 7,
    "embedding_dim": 1536,          # OpenAI ada-002 / most models
    "max_short_term": 10_000,       # Max short-term memories before consolidation
    "max_long_term": 100_000,       # Max long-term memories
    "consolidation_threshold": 0.7, # Importance threshold for promotion to long-term
    "pruning_threshold": 0.05,      # Combined score below this → prune
    "retrieval_strategies": {
        "balanced":   {"semantic": 0.4, "recency": 0.3, "importance": 0.3},
        "recency":    {"semantic": 0.3, "recency": 0.5, "importance": 0.2},
        "importance": {"semantic": 0.3, "recency": 0.2, "importance": 0.5},
    },
}


# ─── SQLite Schema ────────────────────────────────────────────────────────────

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS knowledge_cache (
    id TEXT PRIMARY KEY,
    fact TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    source TEXT,
    source_type TEXT DEFAULT 'unknown',
    confidence REAL DEFAULT 1.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count INTEGER DEFAULT 0,
    verified_by TEXT DEFAULT NULL,
    tags TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS importance_scores (
    memory_id TEXT PRIMARY KEY,
    base_importance REAL DEFAULT 0.5,
    reinforcement_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    manual_pin BOOLEAN DEFAULT FALSE,
    decay_exempt BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS memory_metadata (
    memory_id TEXT PRIMARY KEY,
    layer TEXT DEFAULT 'short_term',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count INTEGER DEFAULT 0,
    source_agent TEXT,
    conversation_id TEXT,
    tags TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS consolidation_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    memory_id TEXT,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_knowledge_category ON knowledge_cache(category);
CREATE INDEX IF NOT EXISTS idx_knowledge_confidence ON knowledge_cache(confidence);
CREATE INDEX IF NOT EXISTS idx_metadata_layer ON memory_metadata(layer);
CREATE INDEX IF NOT EXISTS idx_metadata_conversation ON memory_metadata(conversation_id);
"""


# ─── Memory Engine ────────────────────────────────────────────────────────────

class MemoryEngine:
    """
    Orchestrates the full memory system: vector store + structured store + scoring.
    """

    def __init__(self, db_path: str = "./data/memory", read_only: bool = False,
                 config: dict = None):
        self.db_path = Path(db_path)
        self.db_path.mkdir(parents=True, exist_ok=True)
        self.read_only = read_only
        self.config = {**DEFAULT_CONFIG, **(config or {})}

        # Initialize SQLite
        self._sqlite = sqlite3.connect(
            str(self.db_path / "structured.db"),
            check_same_thread=False,
        )
        self._sqlite.row_factory = sqlite3.Row
        if not read_only:
            self._sqlite.executescript(SQLITE_SCHEMA)

        # Initialize LanceDB (if available)
        self._lance_db = None
        self._memories_table = None
        if LANCEDB_AVAILABLE:
            self._lance_db = lancedb.connect(str(self.db_path / "vectors"))
            self._init_lance_tables()

        logger.info(f"Memory engine initialized at {db_path} "
                     f"(read_only={read_only}, lancedb={LANCEDB_AVAILABLE})")

    def _init_lance_tables(self):
        """Create or open LanceDB tables."""
        table_name = "memories"
        try:
            self._memories_table = self._lance_db.open_table(table_name)
        except Exception:
            # Table doesn't exist, create it
            schema = pa.schema([
                pa.field("id", pa.string()),
                pa.field("text", pa.string()),
                pa.field("vector", pa.list_(pa.float32(), self.config["embedding_dim"])),
                pa.field("timestamp", pa.string()),
                pa.field("importance", pa.float32()),
                pa.field("access_count", pa.int32()),
                pa.field("layer", pa.string()),
                pa.field("source_agent", pa.string()),
                pa.field("conversation_id", pa.string()),
                pa.field("tags", pa.string()),
            ])
            # Create with empty data matching schema
            self._memories_table = self._lance_db.create_table(
                table_name, schema=schema
            )

    # ─── Store ────────────────────────────────────────────────────────

    def store(self, text: str, embedding: list[float],
              metadata: dict = None) -> str:
        """
        Store a new memory.

        Args:
            text: The memory content
            embedding: Vector embedding of the text
            metadata: Optional metadata (source_agent, conversation_id, tags, signals)

        Returns:
            Memory ID
        """
        if self.read_only:
            raise PermissionError("Memory engine is read-only for this agent")

        metadata = metadata or {}
        memory_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()

        # Calculate importance
        importance = self._calculate_importance(text, metadata)

        # Store vector in LanceDB
        if self._memories_table is not None:
            self._memories_table.add([{
                "id": memory_id,
                "text": text,
                "vector": embedding,
                "timestamp": now,
                "importance": importance,
                "access_count": 0,
                "layer": "short_term",
                "source_agent": metadata.get("source_agent", "unknown"),
                "conversation_id": metadata.get("conversation_id", ""),
                "tags": json.dumps(metadata.get("tags", [])),
            }])

        # Store metadata in SQLite
        self._sqlite.execute(
            "INSERT INTO memory_metadata (memory_id, layer, created_at, source_agent, "
            "conversation_id, tags) VALUES (?, ?, ?, ?, ?, ?)",
            (memory_id, "short_term", now,
             metadata.get("source_agent", "unknown"),
             metadata.get("conversation_id", ""),
             json.dumps(metadata.get("tags", [])))
        )

        # Store importance score
        self._sqlite.execute(
            "INSERT INTO importance_scores (memory_id, base_importance) VALUES (?, ?)",
            (memory_id, importance)
        )

        self._sqlite.commit()

        logger.debug(f"Stored memory {memory_id[:8]} (importance={importance:.2f})")
        return memory_id

    # ─── Retrieve ─────────────────────────────────────────────────────

    def retrieve(self, query_embedding: list[float], top_k: int = 10,
                 strategy: str = "balanced",
                 filters: dict = None) -> list[dict]:
        """
        Layered retrieval with configurable scoring strategy.

        Args:
            query_embedding: Vector embedding of the query
            top_k: Number of results to return
            strategy: "balanced", "recency", "importance", or "exact"
            filters: Optional {"layer": str, "source_agent": str, "tags": list}

        Returns:
            List of memory dicts sorted by final_score
        """
        results = []

        # For "exact" strategy, check knowledge cache first
        if strategy == "exact":
            cached = self._search_knowledge_cache_by_embedding(query_embedding)
            if cached:
                return cached[:top_k]

        # Vector search in LanceDB
        if self._memories_table is not None:
            try:
                search = self._memories_table.search(query_embedding).limit(top_k * 3)
                raw_results = search.to_list()
            except Exception as e:
                logger.warning(f"LanceDB search failed: {e}")
                raw_results = []
        else:
            raw_results = []

        # Get scoring weights for strategy
        weights = self.config["retrieval_strategies"].get(
            strategy, self.config["retrieval_strategies"]["balanced"]
        )

        # Score each result
        for r in raw_results:
            # Apply filters
            if filters:
                if filters.get("layer") and r.get("layer") != filters["layer"]:
                    continue
                if filters.get("source_agent") and r.get("source_agent") != filters["source_agent"]:
                    continue

            semantic_score = 1.0 - r.get("_distance", 0.5)
            recency_score = self._recency_score(r.get("timestamp", ""))
            importance_score = r.get("importance", 0.5)

            final_score = (
                semantic_score * weights["semantic"]
                + recency_score * weights["recency"]
                + importance_score * weights["importance"]
            )

            # Boost pinned memories
            importance_row = self._sqlite.execute(
                "SELECT manual_pin, decay_exempt FROM importance_scores WHERE memory_id = ?",
                (r["id"],)
            ).fetchone()

            if importance_row and importance_row["manual_pin"]:
                final_score = min(final_score * 1.5, 1.0)

            results.append({
                "id": r["id"],
                "text": r["text"],
                "timestamp": r.get("timestamp"),
                "layer": r.get("layer"),
                "semantic_score": round(semantic_score, 4),
                "recency_score": round(recency_score, 4),
                "importance_score": round(importance_score, 4),
                "final_score": round(final_score, 4),
                "source_agent": r.get("source_agent"),
                "tags": json.loads(r.get("tags", "[]")),
            })

            # Update access count
            if not self.read_only:
                self._sqlite.execute(
                    "UPDATE memory_metadata SET access_count = access_count + 1, "
                    "last_accessed = ? WHERE memory_id = ?",
                    (datetime.utcnow().isoformat(), r["id"])
                )

        if not self.read_only:
            self._sqlite.commit()

        # Sort by final score and return top_k
        results.sort(key=lambda x: x["final_score"], reverse=True)
        return results[:top_k]

    # ─── Knowledge Cache ──────────────────────────────────────────────

    def store_fact(self, fact: str, category: str = "general",
                   source: str = None, confidence: float = 1.0,
                   verified_by: str = None, tags: list = None) -> str:
        """Store a verified fact in the knowledge cache."""
        if self.read_only:
            raise PermissionError("Memory engine is read-only")

        fact_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()

        self._sqlite.execute(
            "INSERT OR REPLACE INTO knowledge_cache "
            "(id, fact, category, source, confidence, created_at, updated_at, "
            "verified_by, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (fact_id, fact, category, source, confidence, now, now,
             verified_by, json.dumps(tags or []))
        )
        self._sqlite.commit()

        logger.debug(f"Stored fact {fact_id[:8]} ({category}, confidence={confidence})")
        return fact_id

    def lookup_facts(self, query: str = None, category: str = None,
                     min_confidence: float = 0.0,
                     limit: int = 20) -> list[dict]:
        """Search the knowledge cache."""
        conditions = ["confidence >= ?"]
        params = [min_confidence]

        if query:
            conditions.append("fact LIKE ?")
            params.append(f"%{query}%")
        if category:
            conditions.append("category = ?")
            params.append(category)

        where = " AND ".join(conditions)
        rows = self._sqlite.execute(
            f"SELECT * FROM knowledge_cache WHERE {where} "
            f"ORDER BY confidence DESC, accessed_at DESC LIMIT ?",
            (*params, limit)
        ).fetchall()

        # Update access counts
        for row in rows:
            if not self.read_only:
                self._sqlite.execute(
                    "UPDATE knowledge_cache SET access_count = access_count + 1, "
                    "accessed_at = ? WHERE id = ?",
                    (datetime.utcnow().isoformat(), row["id"])
                )

        if not self.read_only:
            self._sqlite.commit()

        return [dict(row) for row in rows]

    # ─── Scoring ──────────────────────────────────────────────────────

    def _recency_score(self, timestamp_str: str) -> float:
        """Exponential decay with configurable half-life."""
        if not timestamp_str:
            return 0.0
        try:
            created = datetime.fromisoformat(timestamp_str)
            age_seconds = (datetime.utcnow() - created).total_seconds()
            half_life_seconds = self.config["recency_half_life_days"] * 86400
            return math.exp(-0.693 * age_seconds / half_life_seconds)
        except (ValueError, OverflowError):
            return 0.0

    def _calculate_importance(self, text: str, metadata: dict) -> float:
        """
        Heuristic importance scoring based on signals.

        Signals that increase importance:
        - user_explicit: User said "remember this"
        - decision: Contains a decision or conclusion
        - error_correction: Corrected a previous mistake
        - preference: Captures a user preference
        - repeated: Mentioned multiple times
        - emotional: Contains emotional significance
        """
        score = 0.5  # Baseline

        signals = metadata.get("signals", {})
        if signals.get("user_explicit"):      score += 0.3
        if signals.get("decision"):           score += 0.2
        if signals.get("error_correction"):   score += 0.2
        if signals.get("preference"):         score += 0.15
        if signals.get("repeated"):           score += 0.1
        if signals.get("emotional"):          score += 0.1

        # Length heuristic — very short or very long memories are less important
        word_count = len(text.split())
        if word_count < 5:
            score -= 0.1
        elif word_count > 500:
            score -= 0.05

        return max(0.0, min(1.0, score))

    def _search_knowledge_cache_by_embedding(self, embedding: list) -> list:
        """Placeholder for semantic search over knowledge cache."""
        # In a full implementation, knowledge cache entries would also be embedded
        # For now, returns empty — callers fall through to vector search
        return []

    # ─── Consolidation ────────────────────────────────────────────────

    def consolidate(self) -> dict:
        """
        Background maintenance job. Should be run periodically (e.g., hourly).

        Actions:
        1. Promote high-importance short-term → long-term
        2. Merge similar memories (deduplicate)
        3. Prune low-value memories (low importance + low recency)
        4. Update access statistics
        """
        if self.read_only:
            raise PermissionError("Cannot consolidate in read-only mode")

        stats = {"promoted": 0, "pruned": 0, "merged": 0}
        now = datetime.utcnow().isoformat()

        # 1. Promote high-importance short-term memories
        promotable = self._sqlite.execute(
            "SELECT m.memory_id FROM memory_metadata m "
            "JOIN importance_scores i ON m.memory_id = i.memory_id "
            "WHERE m.layer = 'short_term' AND i.base_importance >= ?",
            (self.config["consolidation_threshold"],)
        ).fetchall()

        for row in promotable:
            self._sqlite.execute(
                "UPDATE memory_metadata SET layer = 'long_term' WHERE memory_id = ?",
                (row["memory_id"],)
            )
            self._sqlite.execute(
                "INSERT INTO consolidation_log (action, memory_id, details) "
                "VALUES ('promote', ?, 'short_term → long_term')",
                (row["memory_id"],)
            )
            stats["promoted"] += 1

        # 2. Prune low-value, old short-term memories
        cutoff = (datetime.utcnow() - timedelta(
            days=self.config["recency_half_life_days"] * 4
        )).isoformat()

        prunable = self._sqlite.execute(
            "SELECT m.memory_id FROM memory_metadata m "
            "JOIN importance_scores i ON m.memory_id = i.memory_id "
            "WHERE m.layer = 'short_term' "
            "AND m.created_at < ? "
            "AND i.base_importance < ? "
            "AND i.manual_pin = FALSE "
            "AND i.decay_exempt = FALSE",
            (cutoff, self.config["pruning_threshold"] + 0.3)
        ).fetchall()

        for row in prunable:
            memory_id = row["memory_id"]
            self._sqlite.execute(
                "DELETE FROM memory_metadata WHERE memory_id = ?", (memory_id,)
            )
            self._sqlite.execute(
                "DELETE FROM importance_scores WHERE memory_id = ?", (memory_id,)
            )
            self._sqlite.execute(
                "INSERT INTO consolidation_log (action, memory_id, details) "
                "VALUES ('prune', ?, 'low importance + old')",
                (memory_id,)
            )
            # Also delete from LanceDB
            if self._memories_table is not None:
                try:
                    self._memories_table.delete(f"id = '{memory_id}'")
                except Exception:
                    pass  # Best effort
            stats["pruned"] += 1

        self._sqlite.commit()

        logger.info(f"Consolidation complete: {stats}")
        return stats

    # ─── Utilities ────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        """Return memory system statistics."""
        short_term = self._sqlite.execute(
            "SELECT COUNT(*) as cnt FROM memory_metadata WHERE layer = 'short_term'"
        ).fetchone()["cnt"]

        long_term = self._sqlite.execute(
            "SELECT COUNT(*) as cnt FROM memory_metadata WHERE layer = 'long_term'"
        ).fetchone()["cnt"]

        facts = self._sqlite.execute(
            "SELECT COUNT(*) as cnt FROM knowledge_cache"
        ).fetchone()["cnt"]

        pinned = self._sqlite.execute(
            "SELECT COUNT(*) as cnt FROM importance_scores WHERE manual_pin = TRUE"
        ).fetchone()["cnt"]

        return {
            "short_term_memories": short_term,
            "long_term_memories": long_term,
            "knowledge_cache_facts": facts,
            "pinned_memories": pinned,
            "lancedb_available": LANCEDB_AVAILABLE,
        }

    def pin_memory(self, memory_id: str):
        """Manually pin a memory (prevents decay and pruning)."""
        if self.read_only:
            raise PermissionError("Memory engine is read-only")
        self._sqlite.execute(
            "UPDATE importance_scores SET manual_pin = TRUE WHERE memory_id = ?",
            (memory_id,)
        )
        self._sqlite.commit()

    def unpin_memory(self, memory_id: str):
        """Remove manual pin from a memory."""
        if self.read_only:
            raise PermissionError("Memory engine is read-only")
        self._sqlite.execute(
            "UPDATE importance_scores SET manual_pin = FALSE WHERE memory_id = ?",
            (memory_id,)
        )
        self._sqlite.commit()
